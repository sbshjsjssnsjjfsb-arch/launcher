#!/usr/bin/env python3
"""
Простой тестовый сервер для разработки: раздаёт текущую папку по HTTP
и поддерживает докачку (заголовок Range), как настоящий веб-сервер.

    cd backend
    python3 dev_server.py          # слушает 0.0.0.0:8080

Из эмулятора Android Studio сервер виден по адресу http://10.0.2.2:8080/launcher.json
С реального телефона — по IP компьютера в Wi-Fi сети, например http://192.168.1.10:8080/launcher.json
(для такого адреса в make_manifest.py укажи --base-url http://192.168.1.10:8080/files/).

Только для тестов. На боевом хостинге используй nginx/Apache + HTTPS.
"""
import http.server
import os
import re
import sys
import urllib.parse

ROOT = os.path.dirname(os.path.abspath(__file__))


class Handler(http.server.BaseHTTPRequestHandler):
    def do_GET(self):
        rel = urllib.parse.unquote(self.path.split("?")[0]).lstrip("/")
        full = os.path.realpath(os.path.join(ROOT, rel))
        if not full.startswith(ROOT + os.sep) or not os.path.isfile(full):
            self.send_error(404)
            return

        size = os.path.getsize(full)
        start = 0
        m = re.match(r"bytes=(\d+)-", self.headers.get("Range", ""))
        if m:
            start = int(m.group(1))
            if start >= size:
                self.send_response(416)
                self.send_header("Content-Range", f"bytes */{size}")
                self.end_headers()
                return
            self.send_response(206)
            self.send_header("Content-Range", f"bytes {start}-{size - 1}/{size}")
        else:
            self.send_response(200)

        self.send_header("Content-Length", str(size - start))
        self.send_header("Accept-Ranges", "bytes")
        self.end_headers()
        with open(full, "rb") as f:
            f.seek(start)
            while True:
                chunk = f.read(256 * 1024)
                if not chunk:
                    break
                try:
                    self.wfile.write(chunk)
                except (BrokenPipeError, ConnectionResetError):
                    return

    def log_message(self, fmt, *args):
        print(self.address_string(), fmt % args)


if __name__ == "__main__":
    port = int(sys.argv[1]) if len(sys.argv) > 1 else 8080
    print(f"Раздаю {ROOT} на порту {port}")
    http.server.ThreadingHTTPServer(("0.0.0.0", port), Handler).serve_forever()
