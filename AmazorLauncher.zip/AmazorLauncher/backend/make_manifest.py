#!/usr/bin/env python3
"""
Собирает launcher.json для лаунчера: берёт шаблон (новости, серверы), считает размер и
SHA-256 всех файлов игры в папке и (по желанию) данные APK клиента.

Пример:
    python3 make_manifest.py \
        --files-dir ./files \
        --base-url https://example.com/launcher/files/ \
        --client-apk ./client.apk \
        --client-package com.example.crmpclient \
        --client-version-code 3 \
        --client-apk-url https://example.com/launcher/client.apk \
        --out ./launcher.json

После этого выложи на хостинг: launcher.json, папку files/ и client.apk.
"""
import argparse
import hashlib
import json
import sys
from pathlib import Path


def sha256_of(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def collect_files(root: Path):
    for p in sorted(root.rglob("*")):
        if not p.is_file():
            continue
        rel = p.relative_to(root)
        # Служебные и скрытые файлы в манифест не попадают.
        if any(part.startswith(".") for part in rel.parts) or p.suffix == ".part":
            continue
        yield p, rel.as_posix()


def main() -> int:
    ap = argparse.ArgumentParser(description="Генератор launcher.json")
    ap.add_argument("--files-dir", required=True, type=Path, help="папка с файлами игры")
    ap.add_argument("--base-url", required=True, help="URL, по которому лежит эта папка")
    ap.add_argument("--template", type=Path,
                    default=Path(__file__).with_name("launcher.template.json"),
                    help="шаблон с новостями и серверами")
    ap.add_argument("--out", type=Path, default=Path("launcher.json"))
    ap.add_argument("--client-apk", type=Path, help="APK клиента игры")
    ap.add_argument("--client-package", help="пакет клиента, например com.example.crmpclient")
    ap.add_argument("--client-version-code", type=int, help="versionCode этого APK")
    ap.add_argument("--client-apk-url", help="URL, по которому лежит APK")
    args = ap.parse_args()

    if not args.files_dir.is_dir():
        print(f"Нет папки: {args.files_dir}", file=sys.stderr)
        return 1
    if not args.base_url.startswith(("https://", "http://")):
        print("--base-url должен начинаться с https:// (или http:// для теста)", file=sys.stderr)
        return 1

    config = {}
    if args.template.is_file():
        config = json.loads(args.template.read_text(encoding="utf-8"))

    files = []
    total = 0
    for path, rel in collect_files(args.files_dir):
        size = path.stat().st_size
        files.append({"path": rel, "size": size, "sha256": sha256_of(path)})
        total += size

    config["files_base_url"] = args.base_url if args.base_url.endswith("/") else args.base_url + "/"
    config["files"] = files

    if args.client_apk:
        needed = [args.client_package, args.client_version_code, args.client_apk_url]
        if any(v is None for v in needed):
            print("Для APK нужны --client-package, --client-version-code и --client-apk-url",
                  file=sys.stderr)
            return 1
        config["client"] = {
            "package": args.client_package,
            "version_code": args.client_version_code,
            "apk_url": args.client_apk_url,
            "sha256": sha256_of(args.client_apk),
            "size": args.client_apk.stat().st_size,
        }

    args.out.write_text(json.dumps(config, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(f"Готово: {args.out} — файлов: {len(files)}, объём: {total / 1024 / 1024:.1f} МБ")
    return 0


if __name__ == "__main__":
    sys.exit(main())
