package com.myproject.launcher

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.VideoView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat

/**
 * Загрузочный экран: видео-интро (res/raw/intro.mp4), внизу полоса загрузки
 * с фразами и процентами. Нажатие на экран пропускает интро.
 * Чтобы заменить видео, положи свой файл в res/raw/ под именем intro.mp4.
 */
class SplashActivity : AppCompatActivity() {

    private val handler = Handler(Looper.getMainLooper())
    private lateinit var video: VideoView
    private lateinit var statusText: TextView
    private lateinit var percentText: TextView
    private lateinit var progressBar: ProgressBar
    private lateinit var phrases: Array<String>
    private var opened = false

    private val ticker = object : Runnable {
        override fun run() {
            updateProgress()
            handler.postDelayed(this, TICK_MS)
        }
    }
    private val timeout = Runnable { openMain() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash)
        hideSystemBars()

        video = findViewById(R.id.splashVideo)
        statusText = findViewById(R.id.splashStatus)
        percentText = findViewById(R.id.splashPercent)
        progressBar = findViewById(R.id.splashProgress)
        phrases = resources.getStringArray(R.array.splash_phrases)

        video.setOnPreparedListener { mp -> mp.setVolume(VOLUME, VOLUME) }
        video.setOnCompletionListener { openMain() }
        video.setOnErrorListener { _, _, _ ->
            openMain()
            true
        }
        video.setVideoURI(Uri.parse("android.resource://$packageName/${R.raw.intro}"))

        findViewById<View>(R.id.splashRoot).setOnClickListener { openMain() }
    }

    override fun onResume() {
        super.onResume()
        if (opened) return
        video.start()
        handler.post(ticker)
        handler.postDelayed(timeout, MAX_SPLASH_MS)
    }

    override fun onPause() {
        handler.removeCallbacks(ticker)
        handler.removeCallbacks(timeout)
        if (!opened) video.pause()
        super.onPause()
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        video.stopPlayback()
        super.onDestroy()
    }

    private fun updateProgress() {
        val duration = video.duration
        val position = video.currentPosition
        val p = if (duration > 0) (position * 1000L / duration).toInt().coerceIn(0, 1000) else 0
        progressBar.progress = p
        percentText.text = "${p / 10}%"
        if (phrases.isNotEmpty()) {
            val index = (p * phrases.size / 1001).coerceIn(0, phrases.size - 1)
            statusText.text = phrases[index]
        }
    }

    @Suppress("DEPRECATION")
    private fun openMain() {
        if (opened) return
        opened = true
        handler.removeCallbacksAndMessages(null)
        startActivity(Intent(this, MainActivity::class.java))
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
        finish()
    }

    private fun hideSystemBars() {
        WindowCompat.setDecorFitsSystemWindows(window, false)
        val controller = WindowInsetsControllerCompat(window, window.decorView)
        controller.hide(WindowInsetsCompat.Type.systemBars())
        controller.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
    }

    companion object {
        private const val TICK_MS = 40L
        private const val MAX_SPLASH_MS = 9000L
        private const val VOLUME = 0.7f
    }
}
