package com.myproject.launcher

/**
 * ГЛАВНЫЕ НАСТРОЙКИ ЛАУНЧЕРА. Начни отсюда.
 */
object AppConfig {

    /** Адрес файла launcher.json на твоём хостинге (см. папку backend/). */
    const val CONFIG_URL = "http://10.0.2.2:8080/launcher.json"
    // ^ 10.0.2.2 — это "localhost твоего компьютера" внутри эмулятора Android Studio.
    //   Для реального проекта поставь https://твой-домен/launcher/launcher.json

    /**
     * Пакет приложения-клиента игры. Если в launcher.json есть блок "client",
     * оттуда берётся пакет, а это значение — запасное.
     */
    const val CLIENT_PACKAGE = "com.example.crmpclient"

    /**
     * Куда класть файлы игры.
     *  false — в папку самого лаунчера (Android/data/<пакет лаунчера>/files/game).
     *          Не требует разрешений, но на Android 11+ другое приложение
     *          эту папку прочитать НЕ может. Подходит, если клиент и лаунчер — одно приложение.
     *  true  — в общую папку /sdcard/<PUBLIC_DIR_NAME>. Её сможет читать отдельный клиент,
     *          но лаунчеру понадобится доступ ко всем файлам (запрашивается сам).
     */
    const val USE_PUBLIC_DIR = false
    const val PUBLIC_DIR_NAME = "MyProject"

    /** Имена параметров (extras), с которыми лаунчер запускает клиент. Клиент должен их читать. */
    const val EXTRA_NICK = "nickname"
    const val EXTRA_HOST = "host"
    const val EXTRA_PORT = "port"
    const val EXTRA_GAME_DIR = "game_dir"

    /** Запас свободного места сверх размера загрузки. */
    const val MIN_FREE_BYTES = 100L * 1024 * 1024

    /** Как часто обновлять онлайн серверов, мс. */
    const val ONLINE_REFRESH_MS = 15_000L
}
