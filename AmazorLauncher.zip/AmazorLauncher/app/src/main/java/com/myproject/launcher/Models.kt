package com.myproject.launcher

data class ServerInfo(val name: String, val ip: String, val port: Int)

data class NewsItem(val title: String, val text: String, val date: String)

/** Один файл игры из манифеста. path — относительный, с разделителем "/". */
data class FileEntry(val path: String, val size: Long, val sha256: String)

/** APK клиента игры, который лаунчер может скачать и установить. */
data class ClientInfo(
    val packageName: String,
    val versionCode: Long,
    val apkUrl: String,
    val sha256: String,
    val size: Long,
)

/** Всё, что лаунчер получает с твоего сервера (launcher.json). */
data class RemoteConfig(
    val minLauncherVersion: Int,
    val launcherUrl: String,
    val news: List<NewsItem>,
    val servers: List<ServerInfo>,
    val filesBaseUrl: String,
    val files: List<FileEntry>,
    val client: ClientInfo?,
)

data class ServerStatus(
    val players: Int,
    val maxPlayers: Int,
    val hostname: String,
    val pingMs: Long,
)
