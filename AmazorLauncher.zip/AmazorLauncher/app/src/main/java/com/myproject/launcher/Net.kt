package com.myproject.launcher

import android.os.SystemClock
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import okhttp3.HttpUrl
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.IOException
import java.security.MessageDigest
import java.util.concurrent.TimeUnit

object Http {
    val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .followRedirects(true)
        .build()

    fun parseUrl(url: String): HttpUrl =
        url.toHttpUrlOrNull() ?: throw IOException("Некорректный адрес: $url")

    /** base + относительный путь файла, с правильным кодированием символов. */
    fun fileUrl(base: String, path: String): HttpUrl =
        parseUrl(base).newBuilder().addPathSegments(path.trimStart('/')).build()
}

object Hashing {
    fun sha256(file: File): String {
        val md = MessageDigest.getInstance("SHA-256")
        FileInputStream(file).use { input ->
            val buf = ByteArray(256 * 1024)
            while (true) {
                val n = input.read(buf)
                if (n < 0) break
                md.update(buf, 0, n)
            }
        }
        return md.digest().joinToString("") { "%02x".format(it) }
    }
}

/**
 * Скачивание одного файла: докачка (.part + Range), проверка размера и SHA-256,
 * 3 попытки при сетевых ошибках.
 */
object Downloader {

    /** onBytes вызывается из фонового потока: сколько байт этого файла уже есть. */
    suspend fun download(
        url: HttpUrl,
        target: File,
        expectedSize: Long,
        expectedSha256: String,
        onBytes: (Long) -> Unit,
    ) = withContext(Dispatchers.IO) {
        var attempt = 0
        while (true) {
            try {
                downloadOnce(url, target, expectedSize, expectedSha256, onBytes)
                break
            } catch (e: IOException) {
                attempt++
                if (attempt >= 3) throw e
                delay(1500L * attempt)
            }
        }
    }

    private suspend fun downloadOnce(
        url: HttpUrl,
        target: File,
        expectedSize: Long,
        expectedSha256: String,
        onBytes: (Long) -> Unit,
    ) {
        val part = File(target.path + ".part")
        part.parentFile?.mkdirs()
        if (!part.exists()) part.createNewFile()

        var offset = part.length()
        if (offset > expectedSize) {
            part.delete()
            part.createNewFile()
            offset = 0L
        }

        if (offset < expectedSize) {
            val request = Request.Builder().url(url).apply {
                if (offset > 0) header("Range", "bytes=$offset-")
            }.build()

            Http.client.newCall(request).execute().use { resp ->
                if (resp.code == 416) {
                    // Файл на сервере изменился — начинаем заново.
                    part.delete()
                    throw IOException("HTTP 416 для ${target.name}")
                }
                if (!resp.isSuccessful) throw IOException("HTTP ${resp.code} для ${target.name}")

                // 206 — сервер продолжил с нужного места; 200 — прислал файл целиком.
                val append = resp.code == 206 && offset > 0
                if (!append) offset = 0L
                val body = resp.body ?: throw IOException("Пустой ответ сервера")

                body.byteStream().use { input ->
                    FileOutputStream(part, append).use { out ->
                        val buf = ByteArray(64 * 1024)
                        var written = offset
                        var lastReport = 0L
                        onBytes(written)
                        while (true) {
                            currentCoroutineContext().ensureActive()
                            val n = input.read(buf)
                            if (n < 0) break
                            out.write(buf, 0, n)
                            written += n
                            val now = SystemClock.elapsedRealtime()
                            if (now - lastReport >= 150) {
                                lastReport = now
                                onBytes(written)
                            }
                        }
                        onBytes(written)
                    }
                }
            }
        }

        if (part.length() != expectedSize) {
            part.delete()
            throw IOException("Неверный размер файла ${target.name}")
        }
        if (!Hashing.sha256(part).equals(expectedSha256, ignoreCase = true)) {
            part.delete()
            throw IOException("Контрольная сумма не совпала: ${target.name}")
        }
        if (target.exists()) target.delete()
        if (!part.renameTo(target)) throw IOException("Не удалось сохранить ${target.name}")
    }
}
