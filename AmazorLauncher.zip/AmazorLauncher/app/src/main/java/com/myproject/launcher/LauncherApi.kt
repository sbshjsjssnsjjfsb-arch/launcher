package com.myproject.launcher

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException

/** Загрузка и разбор launcher.json с твоего сервера. */
object LauncherApi {

    suspend fun fetchConfig(): RemoteConfig = withContext(Dispatchers.IO) {
        val request = Request.Builder()
            .url(Http.parseUrl(AppConfig.CONFIG_URL))
            .header("Cache-Control", "no-cache")
            .build()
        Http.client.newCall(request).execute().use { resp ->
            if (!resp.isSuccessful) throw IOException("HTTP ${resp.code}")
            val text = resp.body?.string() ?: throw IOException("Пустой ответ сервера")
            parse(text)
        }
    }

    fun parse(text: String): RemoteConfig {
        val root = JSONObject(text)

        val servers = root.optJSONArray("servers").mapObjects {
            ServerInfo(
                name = it.getString("name"),
                ip = it.getString("ip"),
                port = it.optInt("port", 7777),
            )
        }

        val news = root.optJSONArray("news").mapObjects {
            NewsItem(
                title = it.optString("title"),
                text = it.optString("text"),
                date = it.optString("date"),
            )
        }

        val files = root.optJSONArray("files").mapObjects {
            val path = it.getString("path")
            val size = it.getLong("size")
            val sha = it.getString("sha256")
            if (!isSafeRelativePath(path)) throw IOException("Недопустимый путь в манифесте: $path")
            if (size < 0 || !isSha256(sha)) throw IOException("Некорректная запись в манифесте: $path")
            FileEntry(path, size, sha.lowercase())
        }

        val client = root.optJSONObject("client")?.let {
            val sha = it.getString("sha256")
            if (!isSha256(sha)) throw IOException("Некорректный sha256 клиента")
            ClientInfo(
                packageName = it.getString("package"),
                versionCode = it.getLong("version_code"),
                apkUrl = it.getString("apk_url"),
                sha256 = sha.lowercase(),
                size = it.getLong("size"),
            )
        }

        val launcherUrl = root.optString("launcher_url").takeIf {
            it.startsWith("https://") || it.startsWith("http://")
        } ?: ""

        return RemoteConfig(
            minLauncherVersion = root.optInt("min_launcher_version", 0),
            launcherUrl = launcherUrl,
            news = news,
            servers = servers,
            filesBaseUrl = root.optString("files_base_url"),
            files = files,
            client = client,
        )
    }

    /** Путь из манифеста не должен выходить за папку игры. */
    internal fun isSafeRelativePath(p: String): Boolean =
        p.isNotEmpty() &&
            !p.startsWith("/") &&
            p.none { it == '\\' || it == '\t' || it == '\n' || it == '\r' } &&
            p.split('/').none { it.isEmpty() || it == "." || it == ".." } &&
            !p.endsWith(".part") &&
            p != FileSync.CACHE_NAME

    private fun isSha256(s: String): Boolean =
        s.length == 64 && s.all { it in '0'..'9' || it in 'a'..'f' || it in 'A'..'F' }

    private fun <T> JSONArray?.mapObjects(transform: (JSONObject) -> T): List<T> {
        if (this == null) return emptyList()
        val out = ArrayList<T>(length())
        for (i in 0 until length()) out.add(transform(getJSONObject(i)))
        return out
    }
}
