package com.myproject.launcher

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputFilter
import android.text.format.Formatter
import android.view.View
import android.view.WindowManager
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.google.android.material.button.MaterialButton
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.io.IOException

class MainActivity : AppCompatActivity() {

    private lateinit var nickInput: EditText
    private lateinit var serversContainer: LinearLayout
    private lateinit var newsContainer: LinearLayout
    private lateinit var statusText: TextView
    private lateinit var progressBar: ProgressBar
    private lateinit var playButton: MaterialButton

    private val prefs by lazy { getSharedPreferences("launcher", MODE_PRIVATE) }

    private var config: RemoteConfig? = null
    private var selectedIndex = 0
    private val serverViews = mutableListOf<View>()
    private var busy = false
    private var onlineJob: Job? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        nickInput = findViewById(R.id.nickInput)
        serversContainer = findViewById(R.id.serversContainer)
        newsContainer = findViewById(R.id.newsContainer)
        statusText = findViewById(R.id.statusText)
        progressBar = findViewById(R.id.progressBar)
        playButton = findViewById(R.id.playButton)

        nickInput.setText(prefs.getString(KEY_NICK, ""))
        nickInput.filters = arrayOf(InputFilter.LengthFilter(NICK_MAX), nickCharsFilter())

        playButton.setOnClickListener { onPlayClicked() }

        loadConfig()
    }

    // ---------------------------------------------------------------------------------------
    // Получение данных с сервера
    // ---------------------------------------------------------------------------------------

    private fun loadConfig() {
        setStatus(getString(R.string.status_loading))
        playButton.setText(R.string.play)
        playButton.isEnabled = false

        lifecycleScope.launch {
            try {
                val cfg = LauncherApi.fetchConfig()
                renderNews(cfg.news)
                renderServers(cfg.servers)
                startOnlinePolling(cfg.servers)

                if (BuildConfig.VERSION_CODE < cfg.minLauncherVersion) {
                    showLauncherUpdateRequired(cfg)
                    return@launch
                }

                config = cfg
                setStatus(getString(R.string.status_ready))
                playButton.isEnabled = true
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                config = null
                setStatus(getString(R.string.status_config_error, e.message ?: e.javaClass.simpleName))
                playButton.setText(R.string.retry)
                playButton.isEnabled = true
            }
        }
    }

    private fun showLauncherUpdateRequired(cfg: RemoteConfig) {
        setStatus(getString(R.string.update_required))
        val dialog = AlertDialog.Builder(this)
            .setTitle(R.string.update_required)
            .setMessage(R.string.update_required_text)
            .setCancelable(false)
        if (cfg.launcherUrl.isNotBlank()) {
            dialog.setPositiveButton(R.string.download) { _, _ ->
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(cfg.launcherUrl)))
            }
        }
        dialog.show()
    }

    // ---------------------------------------------------------------------------------------
    // Список серверов и новости
    // ---------------------------------------------------------------------------------------

    private fun renderServers(servers: List<ServerInfo>) {
        serversContainer.removeAllViews()
        serverViews.clear()
        selectedIndex = prefs.getInt(KEY_SERVER, 0).coerceIn(0, (servers.size - 1).coerceAtLeast(0))

        servers.forEachIndexed { index, server ->
            val view = layoutInflater.inflate(R.layout.item_server, serversContainer, false)
            view.findViewById<TextView>(R.id.serverName).text = server.name
            view.findViewById<TextView>(R.id.serverAddress).text = "${server.ip}:${server.port}"
            view.findViewById<TextView>(R.id.serverOnline).text = "…"
            view.setOnClickListener { selectServer(index) }
            serversContainer.addView(view)
            serverViews.add(view)
        }
        selectServer(selectedIndex)
    }

    private fun selectServer(index: Int) {
        if (busy || serverViews.isEmpty()) return
        selectedIndex = index
        serverViews.forEachIndexed { i, v -> v.isSelected = (i == index) }
    }

    private fun renderNews(news: List<NewsItem>) {
        newsContainer.removeAllViews()
        if (news.isEmpty()) {
            val empty = TextView(this)
            empty.text = getString(R.string.news_empty)
            empty.setTextColor(getColor(R.color.text_secondary))
            newsContainer.addView(empty)
            return
        }
        for (item in news) {
            val view = layoutInflater.inflate(R.layout.item_news, newsContainer, false)
            view.findViewById<TextView>(R.id.newsTitle).text = item.title
            view.findViewById<TextView>(R.id.newsDate).text = item.date
            view.findViewById<TextView>(R.id.newsText).text = item.text
            newsContainer.addView(view)
        }
    }

    /** Пока экран на виду — раз в несколько секунд обновляем онлайн каждого сервера. */
    private fun startOnlinePolling(servers: List<ServerInfo>) {
        onlineJob?.cancel()
        onlineJob = lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                while (true) {
                    servers.forEachIndexed { index, server ->
                        launch { updateOnline(index, SampQuery.query(server.ip, server.port)) }
                    }
                    delay(AppConfig.ONLINE_REFRESH_MS)
                }
            }
        }
    }

    private fun updateOnline(index: Int, status: ServerStatus?) {
        val view = serverViews.getOrNull(index) ?: return
        val online = view.findViewById<TextView>(R.id.serverOnline)
        if (status == null) {
            online.text = getString(R.string.online_offline)
            online.setTextColor(getColor(R.color.offline))
        } else {
            online.text = getString(R.string.online_format, status.players, status.maxPlayers)
            online.setTextColor(getColor(R.color.ok))
        }
    }

    // ---------------------------------------------------------------------------------------
    // Кнопка «Играть»: клиент → файлы → запуск
    // ---------------------------------------------------------------------------------------

    private fun onPlayClicked() {
        if (busy) return

        val cfg = config
        if (cfg == null) {
            loadConfig()
            return
        }
        if (cfg.servers.isEmpty()) {
            setStatus(getString(R.string.err_no_servers))
            return
        }

        val nick = nickInput.text.toString().trim()
        if (!isValidNick(nick)) {
            nickInput.error = getString(R.string.err_nick)
            return
        }

        if (!GameStorage.hasAccess(this)) {
            requestStorageAccess()
            return
        }

        val server = cfg.servers[selectedIndex]
        prefs.edit().putString(KEY_NICK, nick).putInt(KEY_SERVER, selectedIndex).apply()

        setBusy(true)
        lifecycleScope.launch {
            try {
                runPipeline(cfg, nick, server)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                setStatus(getString(R.string.err_download, e.message ?: e.javaClass.simpleName))
            } finally {
                setBusy(false)
            }
        }
    }

    private suspend fun runPipeline(cfg: RemoteConfig, nick: String, server: ServerInfo) {
        val client = cfg.client
        val clientPackage = client?.packageName ?: AppConfig.CLIENT_PACKAGE

        // 1. Клиент игры: установить или обновить, если нужно.
        if (client != null && !ensureClient(client)) return

        // 2. Файлы игры: проверить и докачать.
        syncFiles(cfg)

        // 3. Запуск.
        setStatus(getString(R.string.status_launching))
        when (val result = GameLauncher.launch(this, clientPackage, nick, server, GameStorage.gameDir(this))) {
            is LaunchResult.Started -> Unit
            is LaunchResult.NotInstalled -> setStatus(getString(R.string.err_client_missing))
            is LaunchResult.Failed -> setStatus(getString(R.string.err_launch, result.message))
        }
    }

    /** true — клиент актуален, можно продолжать. false — пользователю нужно что-то подтвердить. */
    private suspend fun ensureClient(client: ClientInfo): Boolean {
        val apk = ApkInstaller.apkFile(this)
        if (ApkInstaller.installedVersion(this, client.packageName) >= client.versionCode) {
            apk.delete() // старый скачанный APK больше не нужен
            return true
        }

        if (!ApkInstaller.canInstall(this)) {
            setStatus(getString(R.string.status_allow_install))
            ApkInstaller.openInstallPermissionSettings(this)
            return false
        }

        apk.parentFile?.mkdirs()
        setStatus(getString(R.string.status_downloading_client, "0", sizeText(client.size)))
        Downloader.download(Http.parseUrl(client.apkUrl), apk, client.size, client.sha256) { done ->
            runOnUiThread {
                setStatus(getString(R.string.status_downloading_client, sizeText(done), sizeText(client.size)))
                showProgress(done, client.size)
            }
        }
        ApkInstaller.install(this, apk)
        setStatus(getString(R.string.status_install_prompt))
        return false
    }

    private suspend fun syncFiles(cfg: RemoteConfig) {
        val gameDir = GameStorage.gameDir(this)
        if (!gameDir.exists() && !gameDir.mkdirs()) throw IOException(getString(R.string.err_storage))

        val sync = FileSync(gameDir)

        setStatus(getString(R.string.status_checking_files, 0, cfg.files.size))
        val outdated = sync.findOutdated(cfg.files) { checked, total ->
            runOnUiThread {
                setStatus(getString(R.string.status_checking_files, checked, total))
                showProgress(checked.toLong(), total.toLong())
            }
        }
        if (outdated.isEmpty()) return

        val need = outdated.sumOf { it.size }
        if (gameDir.usableSpace < need + AppConfig.MIN_FREE_BYTES) {
            throw IOException(getString(R.string.err_no_space, sizeText(need)))
        }

        sync.download(cfg.filesBaseUrl, outdated) { done, total, _ ->
            runOnUiThread {
                setStatus(getString(R.string.status_downloading, sizeText(done), sizeText(total)))
                showProgress(done, total)
            }
        }
    }

    // ---------------------------------------------------------------------------------------
    // Мелочи интерфейса
    // ---------------------------------------------------------------------------------------

    private fun setStatus(text: String) {
        statusText.text = text
    }

    private fun showProgress(done: Long, total: Long) {
        progressBar.isIndeterminate = false
        progressBar.progress = if (total > 0) (done * 1000 / total).toInt().coerceIn(0, 1000) else 0
    }

    private fun setBusy(value: Boolean) {
        busy = value
        playButton.isEnabled = !value
        nickInput.isEnabled = !value
        progressBar.visibility = if (value) View.VISIBLE else View.INVISIBLE
        if (value) {
            progressBar.isIndeterminate = true
            window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        } else {
            window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        }
    }

    private fun sizeText(bytes: Long): String = Formatter.formatShortFileSize(this, bytes)

    private fun isValidNick(nick: String): Boolean =
        nick.length in NICK_MIN..NICK_MAX && nick.all { NICK_CHARS.indexOf(it) >= 0 }

    /** Пропускает в поле ника только допустимые для SA-MP символы. */
    private fun nickCharsFilter() = InputFilter { source, start, end, _, _, _ ->
        val clean = StringBuilder()
        for (i in start until end) {
            val c = source[i]
            if (NICK_CHARS.indexOf(c) >= 0) clean.append(c)
        }
        if (clean.length == end - start) null else clean
    }

    // ---------------------------------------------------------------------------------------
    // Доступ к общей папке (нужен только при AppConfig.USE_PUBLIC_DIR = true)
    // ---------------------------------------------------------------------------------------

    private fun requestStorageAccess() {
        setStatus(getString(R.string.status_allow_storage))
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            startActivity(
                Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:$packageName"))
            )
        } else {
            ActivityCompat.requestPermissions(
                this, arrayOf(android.Manifest.permission.WRITE_EXTERNAL_STORAGE), REQ_STORAGE
            )
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray,
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQ_STORAGE && GameStorage.hasAccess(this)) onPlayClicked()
    }

    companion object {
        private const val KEY_NICK = "nick"
        private const val KEY_SERVER = "server"
        private const val REQ_STORAGE = 1001

        private const val NICK_MIN = 3
        private const val NICK_MAX = 20
        private const val NICK_CHARS =
            "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_[]()\$@.="
    }
}
