package com.myproject.launcher

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.Inet4Address
import java.net.InetAddress
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.charset.Charset

/**
 * Запрос информации у SA-MP / CRMP / open.mp сервера по стандартному UDP query-протоколу
 * (opcode 'i'): онлайн, максимум игроков, название. Возвращает null, если сервер не ответил.
 */
object SampQuery {

    private val cp1251: Charset = Charset.forName("windows-1251")

    suspend fun query(host: String, port: Int, timeoutMs: Int = 2000): ServerStatus? =
        withContext(Dispatchers.IO) {
            try {
                val addr = InetAddress.getAllByName(host).firstOrNull { it is Inet4Address }
                    ?: return@withContext null

                val request = ByteArray(11)
                "SAMP".toByteArray(Charsets.US_ASCII).copyInto(request, 0)
                addr.address.copyInto(request, 4)
                request[8] = (port and 0xFF).toByte()
                request[9] = ((port shr 8) and 0xFF).toByte()
                request[10] = 'i'.code.toByte()

                DatagramSocket().use { socket ->
                    socket.soTimeout = timeoutMs
                    val started = System.nanoTime()
                    socket.send(DatagramPacket(request, request.size, addr, port))

                    val buf = ByteArray(2048)
                    val reply = DatagramPacket(buf, buf.size)
                    socket.receive(reply)
                    val ping = (System.nanoTime() - started) / 1_000_000

                    parseInfo(buf, reply.length, ping)
                }
            } catch (e: Exception) {
                null
            }
        }

    /** Разбор ответа на 'i': 11 байт заголовка, затем пароль, игроки, максимум, строки. */
    internal fun parseInfo(data: ByteArray, length: Int, pingMs: Long): ServerStatus? {
        if (length < 11 + 1 + 2 + 2 + 4) return null
        if (String(data, 0, 4, Charsets.US_ASCII) != "SAMP" || data[10] != 'i'.code.toByte()) return null

        val bb = ByteBuffer.wrap(data, 0, length).order(ByteOrder.LITTLE_ENDIAN)
        bb.position(11)
        bb.get() // пароль: 0/1
        val players = bb.short.toInt() and 0xFFFF
        val max = bb.short.toInt() and 0xFFFF
        val nameLen = bb.int
        val hostname = if (nameLen in 0..bb.remaining()) {
            val bytes = ByteArray(nameLen)
            bb.get(bytes)
            String(bytes, cp1251)
        } else ""

        return ServerStatus(players, max, hostname, pingMs)
    }
}
