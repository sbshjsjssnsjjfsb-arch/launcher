package com.myproject.launcher

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Environment
import androidx.core.content.ContextCompat
import java.io.File

/** Где лежат файлы игры и есть ли у лаунчера доступ туда. */
object GameStorage {

    fun gameDir(context: Context): File =
        if (AppConfig.USE_PUBLIC_DIR) {
            File(Environment.getExternalStorageDirectory(), AppConfig.PUBLIC_DIR_NAME)
        } else {
            File(context.getExternalFilesDir(null) ?: context.filesDir, "game")
        }

    fun hasAccess(context: Context): Boolean = when {
        !AppConfig.USE_PUBLIC_DIR -> true
        Build.VERSION.SDK_INT >= Build.VERSION_CODES.R -> Environment.isExternalStorageManager()
        else -> ContextCompat.checkSelfPermission(
            context, Manifest.permission.WRITE_EXTERNAL_STORAGE
        ) == PackageManager.PERMISSION_GRANTED
    }
}
