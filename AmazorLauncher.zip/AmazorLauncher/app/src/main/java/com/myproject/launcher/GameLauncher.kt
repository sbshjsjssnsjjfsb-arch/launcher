package com.myproject.launcher

import android.content.Context
import android.content.Intent
import java.io.File

sealed class LaunchResult {
    object Started : LaunchResult()
    object NotInstalled : LaunchResult()
    class Failed(val message: String) : LaunchResult()
}

/**
 * Запуск клиента игры.
 *
 * Лаунчер открывает приложение-клиент и передаёт ему параметры подключения через extras
 * (имена — в AppConfig). Сам клиент должен прочитать их при старте, например:
 *   val nick = intent.getStringExtra("nickname")
 *   val host = intent.getStringExtra("host")
 *   val port = intent.getIntExtra("port", 7777)
 *   val gameDir = intent.getStringExtra("game_dir")
 *
 * Если позже клиент станет частью самого лаунчера (одно приложение), замени тело launch()
 * на запуск своей Activity: startActivity(Intent(context, GameActivity::class.java)...).
 */
object GameLauncher {

    fun launch(
        context: Context,
        clientPackage: String,
        nick: String,
        server: ServerInfo,
        gameDir: File,
    ): LaunchResult {
        val intent = context.packageManager.getLaunchIntentForPackage(clientPackage)
            ?: return LaunchResult.NotInstalled

        intent.putExtra(AppConfig.EXTRA_NICK, nick)
        intent.putExtra(AppConfig.EXTRA_HOST, server.ip)
        intent.putExtra(AppConfig.EXTRA_PORT, server.port)
        intent.putExtra(AppConfig.EXTRA_GAME_DIR, gameDir.absolutePath)
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)

        return try {
            context.startActivity(intent)
            LaunchResult.Started
        } catch (e: Exception) {
            LaunchResult.Failed(e.message ?: e.javaClass.simpleName)
        }
    }
}
