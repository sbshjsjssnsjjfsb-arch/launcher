package com.myproject.launcher

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import java.io.File

/**
 * Сверяет файлы игры в папке gameDir с манифестом и докачивает недостающие/изменённые.
 *
 * Чтобы не считать SHA-256 гигабайтов при каждом запуске, результаты хэширования
 * кешируются в файле .hashcache (путь, размер, время изменения, хэш).
 */
class FileSync(private val gameDir: File) {

    private class CacheEntry(val size: Long, val mtime: Long, val sha: String)

    private val cacheFile = File(gameDir, CACHE_NAME)
    private val cache: MutableMap<String, CacheEntry> by lazy { loadCache() }

    /** Безопасно превращает путь из манифеста в файл внутри gameDir. */
    private fun resolve(path: String): File {
        val root = gameDir.canonicalFile
        val target = File(root, path).canonicalFile
        require(target.path.startsWith(root.path + File.separator)) { "Недопустимый путь: $path" }
        return target
    }

    /** Список файлов, которые надо скачать. onProgress(проверено, всего) — из фонового потока. */
    suspend fun findOutdated(
        files: List<FileEntry>,
        onProgress: (checked: Int, total: Int) -> Unit,
    ): List<FileEntry> = withContext(Dispatchers.IO) {
        gameDir.mkdirs()
        val result = ArrayList<FileEntry>()
        try {
            for ((i, entry) in files.withIndex()) {
                ensureActive()
                if (!isUpToDate(entry)) result.add(entry)
                onProgress(i + 1, files.size)
            }
        } finally {
            saveCache()
        }
        result
    }

    /** Скачивает файлы. onProgress(скачано всего, нужно всего, текущий файл) — из фонового потока. */
    suspend fun download(
        baseUrl: String,
        files: List<FileEntry>,
        onProgress: (done: Long, total: Long, file: String) -> Unit,
    ) = withContext(Dispatchers.IO) {
        val total = files.sumOf { it.size }
        var finished = 0L
        try {
            for (entry in files) {
                ensureActive()
                val target = resolve(entry.path)
                target.parentFile?.mkdirs()
                val base = finished
                Downloader.download(
                    url = Http.fileUrl(baseUrl, entry.path),
                    target = target,
                    expectedSize = entry.size,
                    expectedSha256 = entry.sha256,
                ) { fileDone -> onProgress(base + fileDone, total, entry.path) }
                finished += entry.size
                cache[entry.path] = CacheEntry(target.length(), target.lastModified(), entry.sha256)
            }
        } finally {
            saveCache()
        }
        Unit
    }

    private fun isUpToDate(entry: FileEntry): Boolean {
        val file = resolve(entry.path)
        if (!file.isFile || file.length() != entry.size) return false

        val cached = cache[entry.path]
        val sha = if (cached != null && cached.size == file.length() && cached.mtime == file.lastModified()) {
            cached.sha
        } else {
            Hashing.sha256(file).also {
                cache[entry.path] = CacheEntry(file.length(), file.lastModified(), it)
            }
        }
        return sha.equals(entry.sha256, ignoreCase = true)
    }

    private fun loadCache(): MutableMap<String, CacheEntry> {
        val map = HashMap<String, CacheEntry>()
        if (!cacheFile.isFile) return map
        try {
            cacheFile.forEachLine { line ->
                val p = line.split('\t')
                if (p.size == 4) {
                    val size = p[1].toLongOrNull()
                    val mtime = p[2].toLongOrNull()
                    if (size != null && mtime != null) map[p[0]] = CacheEntry(size, mtime, p[3])
                }
            }
        } catch (e: Exception) {
            map.clear()
        }
        return map
    }

    private fun saveCache() {
        try {
            gameDir.mkdirs()
            cacheFile.bufferedWriter().use { w ->
                for ((path, e) in cache) w.write("$path\t${e.size}\t${e.mtime}\t${e.sha}\n")
            }
        } catch (e: Exception) {
            // Кеш — только оптимизация; если не записался, просто посчитаем хэши заново.
        }
    }

    companion object {
        const val CACHE_NAME = ".hashcache"
    }
}
